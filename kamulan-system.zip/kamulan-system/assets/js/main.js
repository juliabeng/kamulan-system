document.addEventListener('DOMContentLoaded',()=>{console.log('Kamulan assets loaded')})
